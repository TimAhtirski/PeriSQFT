﻿using PdfSharp;
using PdfSharp.Drawing;
using PdfSharp.Pdf;
using PdfSharp.Pdf.IO;
using PeriSQFT.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.Mvc;

namespace PeriSQFT.Controllers
{
    public class HomeController : Controller
    {
        private SPACE11Entities db = new SPACE11Entities();

        //main
        public ActionResult Index()
        {
            return View();
        }//end action      


        //rename floors
        public ActionResult RenameFloors()
        {
            List<string> floors11x17 = new List<string>();
            List<string> floors = new List<string>();
            List<string> unmatchedfloors = new List<string>();
            StringBuilder builder = new StringBuilder();

            floors = db.vw_DWFPDFs.Select(x => x.FNAME).ToList();
            var DWFtoPDFpath = HttpContext.Server.MapPath("~/DwfToPDF");
            if (Directory.Exists(DWFtoPDFpath))
            {
                string[] fileEntries = Directory.GetFiles(DWFtoPDFpath);

                if (fileEntries.Length > 0)
                {
                    foreach (var file in fileEntries)
                    {
                        if (Path.GetFileName(file.ToUpper()).Contains("11X17"))
                        {
                            floors11x17.Add(file.ToUpper());
                        }

                    }
                    foreach (string floor11x17 in floors11x17)
                    {
                        var f = Path.GetFileName(floor11x17).Replace("-11X17.PDF", "");
                        if (floors.Exists(x => x == f))
                        {
                            var x = floor11x17.Replace(Path.GetFileName(floor11x17), f + ".pdf");
                            System.Diagnostics.Debug.WriteLine(x);
                            System.IO.File.Move(floor11x17, x);
                        }
                        else
                        {
                            unmatchedfloors.Add(Path.GetFileName(floor11x17));
                        }
                    }

                    if (unmatchedfloors.Count > 0)
                    {
                        if (unmatchedfloors.Count < 2)
                        {
                            builder.Append("File: <span style='color:red'>" + unmatchedfloors[0] + "</span> doesn't match a floor");
                        }
                        else
                        {
                            builder.Append("Files: <br/>");
                            foreach (string fl in unmatchedfloors)
                            {
                                builder.Append("<span style='color:red'>");
                                builder.Append(fl).Append("</span>").Append("<br/>");
                            }
                            builder.Append("don't match floors");
                        }
                        return Content(builder.ToString());
                    }
                    else
                    {
                        return Content("All files have been renamed.");
                    }
                }
                else
                {
                    return Content("There are no files.");
                }
            }
            else { return Content("Directory dosen't exist."); }
        }//end action


        //find related stores
        public ActionResult FindStores()
        {
            List<string> floors11x17 = new List<string>();
            List<string> floors = new List<string>();
            List<string> stores = new List<string>();
            StringBuilder builder = new StringBuilder();
            floors = db.vw_DWFPDFs.Select(x => x.FNAME).ToList();
            var DWFtoPDFpath = HttpContext.Server.MapPath("~/DwfToPDF");
            if (Directory.Exists(DWFtoPDFpath))
            {
                string[] fileEntries = Directory.GetFiles(DWFtoPDFpath);
                if (fileEntries.Length > 0)
                {
                    foreach (var file in fileEntries)
                    {

                        floors11x17.Add(file.ToUpper());


                    }
                    foreach (string floor11x17 in floors11x17)
                    {
                        string f = string.Empty;
                        if (floor11x17.Contains("11X17"))
                        {
                            f = Path.GetFileName(floor11x17).Replace("-11X17.PDF", "");
                        }
                        if (!floor11x17.Contains("11X17"))
                        {
                            f = Path.GetFileName(floor11x17).Replace(".PDF", "");
                        }

                        if (floors.Exists(x => x == f))
                        {

                            var s = db.vw_DWFPDFs.Where(x => x.FNAME == f).ToList();
                            if (s!=null)
                            {
                                 foreach (var item in s)
                            {
                                stores.Add(item.DIVLOC+" - "+item.STORE);
                            }  
                            }
                         


                            
                        }

                    }

                    if (stores.Count > 0 && stores.Count < 2)
                    {
                        builder.Append(stores[0]);
                        return Content(builder.ToString());
                    }

                    if (stores.Count > 1)
                    {
                        foreach (var store in stores.Distinct())
                        {
                            builder.Append(store+"<br/>");

                        }
                        return Content(builder.ToString());
                    }

                    if (stores.Count == 0)
                    {

                        builder.Append("Stores not found");
                        return Content(builder.ToString());

                    }


                }
                else
                {
                    return Content("There are no files.");
                }
            }
            return Content("Directory dosen't exist.");

        }

        //transfer floor pdfs

        public ActionResult Transfer()
        {

            List<string> files = new List<string>();

            StringBuilder builder = new StringBuilder();

            var DWFtoPDFpath = HttpContext.Server.MapPath("~/DwfToPDF");
            var destination = HttpContext.Server.MapPath("~/Floors");

            if (Directory.Exists(DWFtoPDFpath))
            {
                string[] fileEntries = Directory.GetFiles(DWFtoPDFpath);
                if (fileEntries.Length > 0)
                {
                    foreach (var file in fileEntries)
                    {
                        if (!Path.GetFileName(file.ToUpper()).Contains("11X17"))
                        {
                            files.Add(file.ToUpper());
                            System.IO.File.Copy(file, destination + "/" + Path.GetFileName(file),true);

                        }
                    }

                    if (files.Count > 0 && files.Count < 2)
                    {
                        return Content("File: <span style='color:red'>" + Path.GetFileName(files[0]) + "</span> has been transfered.");
                    }
                    if (files.Count > 1)
                    {
                        builder.Append("Files: <br/>");
                        foreach (var ff in files)
                        {
                            builder.Append("<span style='color:red'>" + Path.GetFileName(ff) + "</span><br/>");

                        }
                        builder.Append("have been transfered.");
                        return Content(builder.ToString());
                    }
                    if (files.Count == 0)
                    {
                        return Content("There are no files to transfer.");
                    }
                }
                else
                {
                    return Content("There are no files to transfer.");
                }
            }

            return Content("Directory dosen't exist.");


        }


        // get list of all stores
        public ActionResult GetAllStores()
        {
            var allstores = db.vw_DWFPDFs.Select(x => new { divloc = x.DIVLOC, storename = x.STORE }).Distinct().ToList();

            StringBuilder builder = new StringBuilder();

            foreach (var item in allstores)
            {
                builder.Append("<input type='checkbox' class='divloc'  value=" + item.divloc + "> ");
                builder.Append(item.divloc + " - " + item.storename).Append("<br/>");

            }

            return Content(builder.ToString());
        }


        //generate cover pages
        public ActionResult CreateCoverPages(String divlocs)
        {

            if (divlocs != null)
            {
                //List<string> dlocs = db.vw_DWFPDFs.Select(x=>x.DIVLOC).Distinct().ToList();
                List<string> dlocs = divlocs.Split(',').ToList<string>();
                foreach (var item in dlocs)
                {
                    CreateCover(item);
                }


                if (dlocs.Count == 1)
                {
                    return Content("Cover page for " + dlocs[0] + " has been generated.");
                }
                else
                {
                    return Content("Cover pages for " + divlocs + " have been generated.");
                }


            }
            else
            {
                return RedirectToAction("Index");
            }


        }


        //get stores from file names from floor folder        
        public ActionResult StoresFromFloorFiles()
        {
            List<string> filenames = new List<string>();
            List<string> DIVLOCS = new List<string>();
            List<Store> stores = new List<Store>();

            var path = HttpContext.Server.MapPath("~/DwfToPDF");
            var path2 = HttpContext.Server.MapPath("~/CoverPage");
            string[] fileEntries = Directory.GetFiles(path);
            if (fileEntries.Length > 0)
            {

                foreach (var file in fileEntries)
                {
                    if (!file.Contains("11x17") || !file.Contains("11X17"))
                    {
                         filenames.Add(Path.GetFileName(file).Replace(".pdf", ""));
                    }
                   
                }

                if (filenames!=null)
                {
                      foreach (var filename in filenames)
                {
                    DIVLOCS.Add(db.vw_DWFPDFs.Where(x => x.FNAME == filename).Select(x => x.DIVLOC).FirstOrDefault());
                }

                foreach (var dloc in DIVLOCS.Distinct())
                {
                    stores.Add(new Store() { DIVLOC = dloc, IndexFile = path2 + "\\" + dloc + "INDEX.pdf", FloorFiles = fileEntries.Where(x => x.Contains(dloc.Substring(2))).ToList() });

                }
                }
              

                if (stores != null)
                {
                    foreach (var store in stores)
                    {
                        MergePdfs(store);
                    }
                    return Content("Files have been merged and sent to portal page.");

                }
                else
                {
                    return Content("Stores not found.");
                }

            }

            else
            {
                return Content("There are no files to merge.");
            }



        }

      

        //create cover page
        public void CreateCover(string DIVLOC = "")
        {
            if (DIVLOC != "")
            {
                int i = 86; //to put text on new line after each iteration
                var stores = db.vw_DWFPDFs.Where(x => x.DIVLOC == DIVLOC).ToList();
                var STORENAME = stores.Select(x => x.STORE).FirstOrDefault();

                // MemoryStream stream = new MemoryStream();
                //create pdf document
                PdfDocument document = new PdfDocument();

                // Create an empty page      
                PdfPage page = document.AddPage();
                page.Orientation = PageOrientation.Landscape; 

                // Get an XGraphics object for drawing     
                XGraphics gfx = XGraphics.FromPdfPage(page);

                // Create a font   
                XFont font = new XFont("Verdana", 10, XFontStyle.Regular);
                XFont font2 = new XFont("Verdana", 9, XFontStyle.Regular);
                XFont font3 = new XFont("Verdana", 8, XFontStyle.Bold);

                //blue rectangle
                XPen pen = new XPen(XColors.Blue, 15);

                gfx.DrawRectangle(pen, 200, 52, 400, 10);


                // store name
                gfx.DrawString(STORENAME, font, XBrushes.White,

                new XRect(0, 50, page.Width, page.Height),

                XStringFormats.TopCenter);

                //spacekey rectangle
                XPen pen2 = new XPen(XColors.Beige, 15);

                gfx.DrawRectangle(pen2, 200, 77, 150, 10);

                // floor rectangle
                XPen pen3 = new XPen(XColors.BlanchedAlmond, 15);

                gfx.DrawRectangle(pen3, 350, 77, 250, 10);


                //spacekey text
                gfx.DrawString("SPACEKEY", font2, XBrushes.Black,

               new XRect(245, 76, page.Width, page.Height),

               XStringFormats.TopLeft);

                //floor text
                gfx.DrawString("FLOOR", font2, XBrushes.Black,

               new XRect(460, 76, page.Width, page.Height),

               XStringFormats.TopLeft);

                //loops


                foreach (var item in stores)
                {
                    i = i + 15;
                    //drawing spacekeys
                    gfx.DrawString(item.SPACEKEY, font2, XBrushes.Black,

                    new XRect(255, i, page.Width, page.Height),

                    XStringFormats.TopLeft);

                    //drawing floors

                    gfx.DrawString(item.FNAME, font2, XBrushes.Black,

                    new XRect(420, i, page.Width, page.Height),

                    XStringFormats.TopLeft);

                    //drawing FLOOR_ID

                    gfx.DrawString(item.FLOOR_ID, font2, XBrushes.Black,

                    new XRect(510, i, page.Width, page.Height),

                    XStringFormats.TopLeft);

                }// end loop


                //drawing buttom text

                gfx.DrawString("The listed plans represent the latest available drawings by floor but may or ", font3, XBrushes.Black,

               new XRect(0, i + 30, page.Width, page.Height),

               XStringFormats.TopCenter);

                gfx.DrawString("may not reflect the data featured on the latest year-end SAPA vintage.", font3, XBrushes.Black,

               new XRect(0, i + 40, page.Width, page.Height),

              XStringFormats.TopCenter);


                //saving document

                var path = HttpContext.Server.MapPath("~/CoverPage");

                document.Save(path + "/" + DIVLOC + "INDEX.pdf");

                //document.Save(stream, false);

                //Response.Clear();

                //Response.ContentType = "application/pdf";

                //Response.AddHeader("content-length", stream.Length.ToString());

                //Response.BinaryWrite(stream.ToArray());

                //Response.Flush();

                //stream.Close();

                //Response.End();
            }


        }


       
        

        //merge floor and index pdf files
        public void MergePdfs(Store store)
        {

           var path = HttpContext.Server.MapPath("~/Stores");
           var path2 = HttpContext.Server.MapPath("~/Portal");
            // Get some file names 
            List<string> files = store.FloorFiles;
            files.Insert(0,store.IndexFile);

            // Open the output document 
            PdfDocument outputDocument = new PdfDocument();

            // Iterate files 
            foreach (string file in files)
            {

                // Open the document to import pages from it. 

                PdfDocument inputDocument = PdfReader.Open(file, PdfDocumentOpenMode.Import);


                // Iterate pages 
                int count = inputDocument.PageCount;
                for (int idx = 0; idx < count; idx++)
                {
                    // Get the page from the external document... 

                    PdfPage page = inputDocument.Pages[idx];

                    // ...and add it to the output document. 

                    outputDocument.AddPage(page);
                }

            }

            // Save the document...             

            outputDocument.Save(path + "/" + store.DIVLOC+".pdf");
            outputDocument.Save(path2 + "/" + store.DIVLOC + ".pdf");


        }


    }
}