﻿using PdfSharp.Drawing;
using PdfSharp.Pdf;
using PeriSQFT.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.Mvc;

namespace PeriSQFT.Controllers
{
    public class HomeController : Controller
    {
        private SPACE11Entities db = new SPACE11Entities();

        //main
        public ActionResult Index()
        {
            return View();
        }//end action       


        //rename floors
        public ActionResult RenameFloors()
        {
            List<string> floors11x17 = new List<string>();
            List<string> floors = new List<string>();
            List<string> unmatchedfloors = new List<string>();
            StringBuilder builder = new StringBuilder();

            floors = db.vw_DWFPDFs.Select(x => x.FNAME).ToList();
            var DWFtoPDFpath = HttpContext.Server.MapPath("~/DwfToPDF");
            if (Directory.Exists(DWFtoPDFpath))
            {
                string[] fileEntries = Directory.GetFiles(DWFtoPDFpath);

                if (fileEntries.Length > 0)
                {
                    foreach (var file in fileEntries)
                    {
                        if (Path.GetFileName(file).Contains("11x17"))
                        {
                            floors11x17.Add(file);
                        }                      

                    }
                    foreach (string floor11x17 in floors11x17)
                    {
                        var f = Path.GetFileName(floor11x17).Replace("-11x17.pdf", "");
                        if (floors.Exists(x => x == f))
                        {
                            var x = floor11x17.Replace(Path.GetFileName(floor11x17), f + ".pdf");
                            System.Diagnostics.Debug.WriteLine(x);
                            System.IO.File.Move(floor11x17, x);
                        }
                        else
                        {
                            unmatchedfloors.Add(Path.GetFileName(floor11x17));
                        }
                    }

                    if (unmatchedfloors.Count > 0)
                    {
                        if (unmatchedfloors.Count < 2)
                        {
                            builder.Append("File: <span style='color:red'>" + unmatchedfloors[0] + "</span> doesn't match a floor");
                        }
                        else
                        {
                            builder.Append("Files: <br/>");
                            foreach (string fl in unmatchedfloors)
                            {
                                builder.Append("<span style='color:red'>");
                                builder.Append(fl).Append("</span>").Append("<br/>");
                            }
                            builder.Append("don't match floors");
                        }
                        return Content(builder.ToString());
                    }
                    else
                    {
                        return Content("All files renamed.");
                    }
                }
                else
                {
                    return Content("There are no files.");
                }
            }
            else { return Content("Directory dosen't exist."); }
        }//end action


        //find related stores
        public ActionResult FindStores()
        {
            List<string> floors11x17 = new List<string>();
            List<string> floors = new List<string>();
            List<string> stores = new List<string>();
            StringBuilder builder = new StringBuilder();
            floors = db.vw_DWFPDFs.Select(x => x.FNAME).ToList();
            var DWFtoPDFpath = HttpContext.Server.MapPath("~/DwfToPDF");
            if (Directory.Exists(DWFtoPDFpath))
            {
                string[] fileEntries = Directory.GetFiles(DWFtoPDFpath);
                if (fileEntries.Length > 0) {
                    foreach (var file in fileEntries)
                    {
                        
                            floors11x17.Add(file);
                         

                    }
                    foreach (string floor11x17 in floors11x17)
                    {
                        string f = string.Empty;
                        if (floor11x17.Contains("11x17"))
                        {
                             f = Path.GetFileName(floor11x17).Replace("-11x17.pdf", "");
                        }
                        if (!floor11x17.Contains("11x17"))
                        {
                             f = Path.GetFileName(floor11x17).Replace(".pdf", "");
                        }

                        if (floors.Exists(x => x == f))
                        {
                           
                            var s = db.vw_DWFPDFs.Where(x => x.FNAME == f).Select(x => x.STORE).FirstOrDefault();
                            stores.Add(s);
                        }

                    }

                    if (stores.Count>0 && stores.Count<2)
                    {
                        builder.Append(stores[0]);
                        return Content(builder.ToString());
                    }

                    if (stores.Count>1)
                    {
                        foreach (var store in stores.Distinct())
                        {
                            builder.Append(store + "<br/>");
                            
                        }
                        return Content(builder.ToString());
                    }

                    if (stores.Count == 0)
                    {
                       
                            builder.Append("Stores not found");
                            return Content(builder.ToString());
                        
                    }


                }
                else
                {
                    return Content("There are no files.");
                }
            }
            return Content("Directory dosen't exist."); 
            
        }
        
        
        //transfer floor pdfs

        public ActionResult Transfer()
        {
           
            List<string> files = new List<string>();
          
            StringBuilder builder = new StringBuilder();
            
            var DWFtoPDFpath = HttpContext.Server.MapPath("~/DwfToPDF");
            var destination = HttpContext.Server.MapPath("~/Floors");

            if (Directory.Exists(DWFtoPDFpath))
            {
                string[] fileEntries = Directory.GetFiles(DWFtoPDFpath);
                if (fileEntries.Length > 0)
                {
                    foreach (var file in fileEntries)
                    {
                        if (!Path.GetFileName(file).Contains("11x17"))
                        {
                             files.Add(file);
                             System.IO.File.Move(file, destination+"/"+Path.GetFileName(file));

                        }
                    }

                    if (files.Count>0 && files.Count<2)
                    {
                        return Content("File: <span style='color:red'>"+Path.GetFileName(files[0])+"</span> was transfered.");
                    }
                    if (files.Count>1)
                    {  
                        builder.Append("Files: <br/>");
                        foreach (var ff in files)
                        {
                            builder.Append("<span style='color:red'>"+Path.GetFileName(ff)+"</span><br/>");
                            
                        }
                        builder.Append("were transfered.");
                        return Content(builder.ToString());
                    }
                    if (files.Count==0)
                    {
                        return Content("There are no files to transfer.");
                    }
                }
                else
                {
                    return Content("There are no files to transfer.");
                }
            }

            return Content("Directory dosen't exist.");      
        
        
        }

        //create cover page

        public void CreateCover()
        {
            MemoryStream stream = new MemoryStream();
            //create pdf document
            PdfDocument document = new PdfDocument();
 
            // Create an empty page      
            PdfPage page = document.AddPage();

            // Get an XGraphics object for drawing     
            XGraphics gfx = XGraphics.FromPdfPage(page);

            // Create a font   
            XFont font = new XFont("Verdana", 10, XFontStyle.Regular);
            XFont font2 = new XFont("Verdana", 9, XFontStyle.Regular);

            // Draw the text 
            XPen pen = new XPen(XColors.Blue, 15);

            gfx.DrawRectangle(pen, 106, 102, 400, 10);

            gfx.DrawString("EASTLAND FURNITURE CLEARANCE (OH)  [71597]", font, XBrushes.White, 
        
            new XRect(0, 100, page.Width, page.Height), 
      
            XStringFormats.TopCenter);

            XPen pen2 = new XPen(XColors.Beige, 15);

            gfx.DrawRectangle(pen2, 106, 127, 400, 10);



            gfx.DrawString("SPACEKEY", font2, XBrushes.Black,

           new XRect(160, 126, page.Width, page.Height),

           XStringFormats.TopLeft);

            gfx.DrawString("FLOOR", font2, XBrushes.Black,

          new XRect(390, 126, page.Width, page.Height),

          XStringFormats.TopLeft);


           

             
         



          
        
            document.Save(stream, false);
        
            Response.Clear();
         
            Response.ContentType = "application/pdf";
           
            Response.AddHeader("content-length", stream.Length.ToString());
     
            Response.BinaryWrite(stream.ToArray());
         
            Response.Flush();
         
            stream.Close();
           
            Response.End(); 
            
        }
 

            


           
   







    }
}