﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PeriSQFT.Models
{
    public class Store
    {

        public string DIVLOC { get; set; }
        public string IndexFile { get; set; }
        public List<string> FloorFiles { get; set; }
    }
}