﻿using PdfSharp;
using PdfSharp.Drawing;
using PdfSharp.Pdf;
using PdfSharp.Pdf.IO;
using PeriSQFT.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.Mvc;

namespace PeriSQFT.Controllers
{
    public class HomeController : Controller
    {
        private SPACE11Entities db = new SPACE11Entities();

        //main
        public ActionResult Index()
        {
            return View();
        }//end action  







        //find related stores
        public ActionResult FindStores()
        {
            List<string> floors11x17 = new List<string>();
            List<string> floors = new List<string>();
            List<string> stores = new List<string>();
            StringBuilder builder = new StringBuilder();
            floors = db.vw_DWFPDFs.Select(x => x.FNAME).ToList();
            var DWFtoPDFpath = HttpContext.Server.MapPath("~/DwfToPDF");
            if (Directory.Exists(DWFtoPDFpath))
            {
                string[] fileEntries = Directory.GetFiles(DWFtoPDFpath);
                if (fileEntries.Length > 0)
                {
                    foreach (var file in fileEntries)
                    {

                        floors11x17.Add(file.ToUpper());


                    }
                    foreach (string floor11x17 in floors11x17)
                    {
                        string f = string.Empty;
                        if (floor11x17.Contains("11X17"))
                        {
                            f = Path.GetFileName(floor11x17).Replace("-11X17.PDF", "");
                        }
                        if (!floor11x17.Contains("11X17"))
                        {
                            f = Path.GetFileName(floor11x17).Replace(".PDF", "");
                        }

                        if (floors.Exists(x => x == f))
                        {

                            var s = db.vw_DWFPDFs.Where(x => x.FNAME == f).ToList();
                            if (s != null)
                            {
                                foreach (var item in s)
                                {
                                    stores.Add(item.DIVLOC + " - " + item.STORE);
                                }
                            }
                        }

                    }

                    if (stores.Count > 0 && stores.Count < 2)
                    {
                        builder.Append("Identified Store: ");
                        builder.Append(stores[0]);
                        return Content(builder.ToString());
                    }

                    if (stores.Count > 1)
                    {
                        builder.Append("Identified Stores: <br/> ");
                        foreach (var store in stores.Distinct())
                        {

                            builder.Append(store + "<br/>");

                        }
                        return Content(builder.ToString());
                    }

                    if (stores.Count == 0)
                    {

                        builder.Append("Stores not found");
                        return Content(builder.ToString());

                    }


                }
                else
                {
                    return Content("There are no files.");
                }
            }
            return Content("Directory dosen't exist.");

        }
        //transfer floor pdfs

        public ActionResult Transfer()
        {
            RenameFloors();
            List<string> files = new List<string>();
            StringBuilder builder = new StringBuilder();

            var DWFtoPDFpath = HttpContext.Server.MapPath("~/DwfToPDF");
            var destination = HttpContext.Server.MapPath("~/Floors");
            var fnames = db.vw_DWFPDFs.Select(x => x.FNAME).Distinct().ToList();
            var notTransfered = new List<string>();

            if (Directory.Exists(DWFtoPDFpath))
            {
                string[] fileEntries = Directory.GetFiles(DWFtoPDFpath);
                if (fileEntries.Length > 0)
                {
                    foreach (var file in fileEntries)
                    {

                        var filename = Path.GetFileName(file.ToUpper());
                        var filenameWithoutPdf = filename.Replace(".PDF", "");

                        if (!filename.Contains("11X17") && fnames.Exists(x => x == filenameWithoutPdf))
                        {
                            files.Add(file.ToUpper());
                            System.IO.File.Copy(file, destination + "/" + Path.GetFileName(file), true);

                        }
                        else
                        {
                            notTransfered.Add(filename);
                        }
                    }

                    if (files.Count == 0)
                    {
                        return Content("There are no files to transfer.");
                    }

                    if (files.Count > 0 && notTransfered.Count < 1)
                    {
                        return Content("<script>  $.ajax({type: 'GET',url: '/Home/StoresFromFloorFiles',cache: false, success: function (data) { $('.panel-body').empty(); $('.panel-body').append(data); }, error: function () { alert('error post'); }});</script>");
                    }
                    if (files.Count > 0 && notTransfered.Count > 0)
                    {
                        builder.Append("<script>$('.panel-default').css('overflow-y','visible');$('.panel-body').css('height','400');</script>");
                       
                        builder.Append("<div style='margin-top:10px;margin-bottom:10px' class='alert alert-danger'><strong>Warning!</strong> Some files don't match floor names.</div>").Append("<div style='height:200px;overflow-y:scroll'>");

                        foreach (var item in notTransfered)
                        {
                            builder.Append("<span style='font-size:0.9em;'>" + item + "</span><br/>");
                        }
                        builder.Append("</div>");
                        builder.Append("<br/><button class='btn btn-primary btn-sm resolve'>GO BACK</button> <button class='btn btn-success btn-sm merge'>PROCEED TO MERGING</button><br/>");
                       
                        return Content(builder.ToString());
                    }
                }
                else
                {
                    return Content("There are no files to transfer.");
                }
            }

            return Content("Directory dosen't exist.");


        }

        //get stores from file names from floor folder        
        public ActionResult StoresFromFloorFiles()
        {
            List<string> matchedFilenames = new List<string>();
            List<string> DIVLOCS = new List<string>();
            List<Store> stores = new List<Store>();
            List<string> divlocsWithoutCoverPages = new List<string>();
            var fnames = db.vw_DWFPDFs.Select(x => x.FNAME).Distinct().ToList(); //flornames from database
            StringBuilder builder = new StringBuilder();

            var path = HttpContext.Server.MapPath("~/DwfToPDF");
            var path2 = HttpContext.Server.MapPath("~/CoverPage");
            var path3 = HttpContext.Server.MapPath("~/Floors");
            var filesFromFloors = Directory.GetFiles(path3); //files from Floors foolder
            string[] fileEntries = Directory.GetFiles(path);
            if (fileEntries.Length > 0)
            {


                //crate a list of matched files (filename==floorname)
                foreach (var file in fileEntries)
                {
                    var fileToUpper = file.ToUpper();
                    var f = Path.GetFileName(fileToUpper).Replace(".PDF", "");
                    if (fnames.Exists(x => x == f))
                    {
                        matchedFilenames.Add(fileToUpper);
                    }
                }

                //create a list of DIVLOCs related to matched files


                if (matchedFilenames.Count > 0) //if matched files >0
                {

                    foreach (var mFilename in matchedFilenames)
                    {
                        var fname = Path.GetFileName(mFilename).Replace(".PDF", ""); //striping out PDF part from filename
                        DIVLOCS.Add(db.vw_DWFPDFs.Where(x => x.FNAME == fname).Select(x => x.DIVLOC).FirstOrDefault()); //add divloc to a list of DIVLOCs
                    }

                    //create a list of divlocs without coverpages

                    foreach (var dloc in DIVLOCS.Distinct())
                    {
                        var fullFilePath = path2 + "/" + dloc + "INDEX.pdf";
                        var fullFilePath2 = path2 + "/" + dloc + "INDEX.PDF";
                        if (System.IO.File.Exists(fullFilePath) || System.IO.File.Exists(fullFilePath2))
                        {
                            //don't do anything  
                        }
                        else
                        {
                            divlocsWithoutCoverPages.Add(dloc);
                            builder.Append(dloc + "<br/>");
                        }
                    }

                    // build a store object that will be passed to Merge function

                    foreach (var dloc in DIVLOCS.Distinct())
                    {
                        var strippedDIVLOC = dloc.Substring(2);

                        var filesContainsDIVLOC = filesFromFloors.Where(x => x.Contains(strippedDIVLOC)).ToList(); //get all files from Floors folder where filename contains DIVLOC minus 2 characters(ex:71003 becomes 003)

                        stores.Add(new Store() { DIVLOC = dloc, IndexFile = path2 + "\\" + dloc + "INDEX.pdf", FloorFiles = filesContainsDIVLOC });

                    }
                } //end if matchedfiles


                // passing store object to MergePdfs

                if (stores.Count > 0 && divlocsWithoutCoverPages.Count < 1)
                {
                    foreach (var store in stores)
                    {
                        MergePdfs(store);
                    }
                    return Content("<div class='alert alert-success'><strong>Success!</strong> All matched files have been merged and transfered.</div>");

                }

                else if (stores.Count > 0 && divlocsWithoutCoverPages.Count > 0)
                {
                    return Content("<h4>Files have been merged and transfered.</h4><br/>Stores merged without coverpages:<br/> <span style='color:red'>" + builder + "</span>");
                }

                else
                {
                    return Content("Stores aren't found.");
                }

            }//end if fileentries

            else
            {
                return Content("There are no files to merge.");
            }

        }
        // get list of all stores
        public ActionResult GetAllStores()
        {
            var allstores = db.vw_DWFPDFs.Select(x => new { divloc = x.DIVLOC, storename = x.STORE }).Distinct().ToList();

            StringBuilder builder = new StringBuilder();

            foreach (var item in allstores)
            {
                builder.Append("<input type='checkbox' class='divloc'  value=" + item.divloc + "> ");
                builder.Append(item.divloc + " - " + item.storename).Append("<br/>");

            }

            return Content(builder.ToString());
        }

        //generate cover pages
        public ActionResult CreateCoverPages(String divlocs)
        {

            if (divlocs != null)
            {
                //List<string> dlocs = db.vw_DWFPDFs.Select(x=>x.DIVLOC).Distinct().ToList();
                List<string> dlocs = divlocs.Split(',').ToList<string>();
                foreach (var item in dlocs)
                {
                    CreateCover(item);
                }


                if (dlocs.Count == 1)
                {
                    return Content("<div class='alert alert-success'><strong>Success!</strong> Cover page has been generated.</div>");
                }
                else
                {
                    return Content("<div class='alert alert-success'><strong>Success!</strong> Cover pages have been generated.</div>");
                }


            }
            else
            {
                return RedirectToAction("Index");
            }


        }

        //print cover pages
        public ActionResult PrintCoverPages(String divlocs)
        {

            if (divlocs != null)
            {

                List<string> dlocs = divlocs.Split(',').ToList<string>();
                List<string> files = new List<string>();
                var path = HttpContext.Server.MapPath("~/CoverPage");

                foreach (var dloc in dlocs)
                {
                    var file = path + "/" + dloc + "INDEX.PDF";

                    if (System.IO.File.Exists(file))
                    {
                        files.Add(file);
                    }

                }
                if (files.Count > 0)
                {
                    // Open the output document 
                    PdfDocument outputDocument = new PdfDocument();

                    // Iterate files 
                    foreach (string file in files)
                    {

                        try
                        {
                            // Open the document to import pages from it.
                            PdfDocument inputDocument = PdfReader.Open(file, PdfDocumentOpenMode.Import);

                            // Iterate pages 
                            int count = inputDocument.PageCount;
                            for (int idx = 0; idx < count; idx++)
                            {
                                // Get the page from the external document... 
                                PdfPage page = inputDocument.Pages[idx];
                                // ...and add it to the output document. 
                                outputDocument.AddPage(page);
                            }
                        }
                        catch
                        {
                            continue;
                        }

                    }

                    // output the document...             

                    byte[] fileContents = null;
                    using (MemoryStream stream = new MemoryStream())
                    {
                        outputDocument.Save(stream, false);
                        fileContents = stream.ToArray();
                    }
                    if (files.Count > 0 && files.Count < 2)
                    {
                        return File(fileContents, "application/pdf", Path.GetFileName(files[0]));
                    }
                    else
                    {
                        return File(fileContents, "application/pdf", "CoverPages.pdf");
                    }

                }

                else
                {
                    return new EmptyResult();
                }



                ///////////////////////////////////////////

            }
            else return new EmptyResult();
        }

        //print stores
        public ActionResult PrintStores(String divlocs)
        {

            if (divlocs != null)
            {

                List<string> dlocs = divlocs.Split(',').ToList<string>();
                List<string> files = new List<string>();
                var path = HttpContext.Server.MapPath("~/Stores");


                foreach (var dloc in dlocs)
                {
                    var file = path + "/" + dloc + ".pdf";
                    if (System.IO.File.Exists(file))
                    {
                        files.Add(file);
                    }

                }
                if (files.Count > 0)
                {
                    // Open the output document 
                    PdfDocument outputDocument = new PdfDocument();

                    // Iterate files 
                    foreach (string file in files)
                    {

                        try
                        {
                            // Open the document to import pages from it.
                            PdfDocument inputDocument = PdfReader.Open(file, PdfDocumentOpenMode.Import);

                            // Iterate pages 
                            int count = inputDocument.PageCount;
                            for (int idx = 0; idx < count; idx++)
                            {
                                // Get the page from the external document... 
                                PdfPage page = inputDocument.Pages[idx];
                                // ...and add it to the output document. 
                                outputDocument.AddPage(page);
                            }

                        }
                        catch
                        {
                            continue;
                        }

                    }

                    // output the document...             

                    byte[] fileContents = null;
                    using (MemoryStream stream = new MemoryStream())
                    {
                        outputDocument.Save(stream, false);
                        fileContents = stream.ToArray();
                    }

                    if (files.Count > 0 && files.Count() < 2)
                    {

                        return File(fileContents, "application/pdf", Path.GetFileName(files[0]));
                    }
                    else
                    {
                        return File(fileContents, "application/pdf", "StorePlans.pdf");
                    }



                }
                else
                {
                    return new EmptyResult();
                }



                ///////////////////////////////////
            }
            else return new EmptyResult();
        }

      

        //delete files from DWFtoPDF

        public ActionResult DeleteFiles()
        {
            var directory = HttpContext.Server.MapPath("~/DwfToPDF");
            if (Directory.Exists(directory))
            {
                string[] fileEntries = Directory.GetFiles(directory);
                if (fileEntries.Length > 0)
                {
                    foreach (var item in fileEntries)
                    {
                        System.IO.File.Delete(item);
                    }
                    return Content("Files have been deleted.");
                }
                return Content("There are no files to delete.");

            }
            else
            {
                return Content("Directory doesn't exist.");
            }


        }

        //create cover page
        public void CreateCover(string DIVLOC = "")
        {
            if (DIVLOC != "")
            {
                int i = 86; //to put text on new line after each iteration
                var stores = db.vw_DWFPDFs.Where(x => x.DIVLOC == DIVLOC).ToList();
                var STORENAME = stores.Select(x => x.STORE).FirstOrDefault();

                // MemoryStream stream = new MemoryStream();
                //create pdf document
                PdfDocument document = new PdfDocument();

                // Create an empty page      
                PdfPage page = document.AddPage();
                page.Orientation = PageOrientation.Landscape;

                // Get an XGraphics object for drawing     
                XGraphics gfx = XGraphics.FromPdfPage(page);

                // Create a font   
                XFont font = new XFont("Verdana", 10, XFontStyle.Regular);
                XFont font2 = new XFont("Verdana", 9, XFontStyle.Regular);
                XFont font3 = new XFont("Verdana", 8, XFontStyle.Bold);

                //blue rectangle
                XPen pen = new XPen(XColors.Blue, 15);

                gfx.DrawRectangle(pen, 200, 52, 400, 10);


                // store name
                gfx.DrawString(STORENAME, font, XBrushes.White,

                new XRect(0, 50, page.Width, page.Height),

                XStringFormats.TopCenter);

                //spacekey rectangle
                XPen pen2 = new XPen(XColors.Beige, 15);

                gfx.DrawRectangle(pen2, 200, 77, 150, 10);

                // floor rectangle
                XPen pen3 = new XPen(XColors.BlanchedAlmond, 15);

                gfx.DrawRectangle(pen3, 350, 77, 250, 10);


                //spacekey text
                gfx.DrawString("SPACEKEY", font2, XBrushes.Black,

               new XRect(245, 76, page.Width, page.Height),

               XStringFormats.TopLeft);

                //floor text
                gfx.DrawString("FLOOR", font2, XBrushes.Black,

               new XRect(460, 76, page.Width, page.Height),

               XStringFormats.TopLeft);

                //loops


                foreach (var item in stores)
                {
                    i = i + 15;
                    //drawing spacekeys
                    gfx.DrawString(item.SPACEKEY, font2, XBrushes.Black,

                    new XRect(255, i, page.Width, page.Height),

                    XStringFormats.TopLeft);

                    //drawing floors

                    gfx.DrawString(item.FNAME, font2, XBrushes.Black,

                    new XRect(420, i, page.Width, page.Height),

                    XStringFormats.TopLeft);

                    //drawing FLOOR_ID

                    gfx.DrawString(item.FLOOR_ID, font2, XBrushes.Black,

                    new XRect(510, i, page.Width, page.Height),

                    XStringFormats.TopLeft);

                }// end loop


                //drawing buttom text

                gfx.DrawString("The listed plans represent the latest available drawings by floor but may or ", font3, XBrushes.Black,

               new XRect(0, i + 30, page.Width, page.Height),

               XStringFormats.TopCenter);

                gfx.DrawString("may not reflect the data featured on the latest year-end SAPA vintage.", font3, XBrushes.Black,

               new XRect(0, i + 40, page.Width, page.Height),

              XStringFormats.TopCenter);


                //saving document

                var path = HttpContext.Server.MapPath("~/CoverPage");

                document.Save(path + "/" + DIVLOC + "INDEX.pdf");


            }


        }


        //merge floor and index pdf files
        public void MergePdfs(Store store)
        {
            var path = HttpContext.Server.MapPath("~/Stores");
            var path2 = HttpContext.Server.MapPath("~/Portal");
            // Get some file names 
            List<string> files = store.FloorFiles;
            if (System.IO.File.Exists(store.IndexFile))
            {
                  files.Insert(0, store.IndexFile);
            }          

            // Open the output document 
            PdfDocument outputDocument = new PdfDocument();

            // Iterate files 
            foreach (string file in files)
            {

                // Open the document to import pages from it. 
                PdfDocument inputDocument = PdfReader.Open(file, PdfDocumentOpenMode.Import);
                // Iterate pages 
                int count = inputDocument.PageCount;
                for (int idx = 0; idx < count; idx++)
                {
                    // Get the page from the external document... 

                    PdfPage page = inputDocument.Pages[idx];

                    // ...and add it to the output document. 

                    outputDocument.AddPage(page);
                }

            }

            // Save the document...          

            outputDocument.Save(path + "/" + store.DIVLOC + ".pdf"); //save to Stores folder
            outputDocument.Save(path2 + "/" + store.DIVLOC + ".pdf");//save to Portal folder

        }

        //rename floors
        public void RenameFloors()
        {
            List<string> floors11x17 = new List<string>();

            var floors = db.vw_DWFPDFs.Select(x => x.FNAME).ToList();
            var DWFtoPDFpath = HttpContext.Server.MapPath("~/DwfToPDF");
            if (Directory.Exists(DWFtoPDFpath))
            {
                string[] fileEntries = Directory.GetFiles(DWFtoPDFpath);
                if (fileEntries.Length > 0)
                {
                    foreach (var file in fileEntries)
                    {
                        if (Path.GetFileName(file.ToUpper()).Contains("11X17"))
                        {
                            floors11x17.Add(file.ToUpper());
                        }
                    }
                    foreach (string floor11x17 in floors11x17)
                    {
                        var f = Path.GetFileName(floor11x17).Replace("-11X17.PDF", "");
                        if (floors.Exists(x => x == f))
                        {
                            var x = floor11x17.Replace(Path.GetFileName(floor11x17), f + ".pdf");
                            System.IO.File.Copy(floor11x17, x, true);
                            System.IO.File.Delete(floor11x17);
                        }
                    }
                }
            }

        }




























    }
}