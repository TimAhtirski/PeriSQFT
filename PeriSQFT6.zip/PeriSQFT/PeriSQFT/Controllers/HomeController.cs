﻿using PdfSharp;
using PdfSharp.Drawing;
using PdfSharp.Pdf;
using PdfSharp.Pdf.IO;
using PeriSQFT.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Text;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;


namespace PeriSQFT.Controllers
{
    public class HomeController : Controller
    {
        private SPACE11Entities db = new SPACE11Entities();

        //main
        public ActionResult Index()
        {
           
            return View();
        }       
        
        //transfer floor pdfs
        public ActionResult Transfer()
        {
            RenameFloors();
            List<string> files = new List<string>();
            StringBuilder builder = new StringBuilder();
            var DWFtoPDFpath = HttpContext.Server.MapPath("~/DwfToPDF");
            var destination = HttpContext.Server.MapPath("~/Floors");

            //var DWFtoPDFpath =@"\\SP000XSTLS01\SPACE_DFS$\SQFT Reports\_DWFS2PDFS";
            //var destination = @"\\MA000XSREA01\e$\SQFTPDFS\Floors";

            var fnames = db.vw_DWFPDFs.Select(x => x.FNAME).Distinct().ToList();
            var notTransfered = new List<string>();

            if (Directory.Exists(DWFtoPDFpath))
            {
                string[] fileEntries = Directory.GetFiles(DWFtoPDFpath);
                if (fileEntries.Length > 0)
                {
                    foreach (var file in fileEntries)
                    {
                        var filename = Path.GetFileName(file.ToUpper());
                        var filenameWithoutPdf = filename.Replace(".PDF", "");

                        if (!filename.Contains("11X17") && fnames.Exists(x => x == filenameWithoutPdf))
                        {
                            files.Add(file.ToUpper());
                            System.IO.File.Copy(file, destination + "/" + Path.GetFileName(file), true);
                        }
                        else
                        {
                            notTransfered.Add(filename);
                        }
                    }
                    if (files.Count == 0 && notTransfered.Count==0)
                    {
                        return Content("There are no files to transfer.");
                    }

                    if (files.Count > 0 && notTransfered.Count == 0)
                    {
                        return Content("<script>  $.ajax({type: 'GET',url: '/Home/StoresFromFloorFiles',cache: false, success: function (data) { $('.panel-body').empty(); $('.panel-body').append(data); }, error: function () { alert('error post'); }});</script>");
                    }
                    if (files.Count > 0 && notTransfered.Count > 0)
                    {
                        builder.Append("<script>$('.panel-default').css('overflow-y','visible');$('.panel-body').css('height','400');</script>");
                       
                        builder.Append("<div style='margin-top:10px;margin-bottom:10px' class='alert alert-danger'><strong>Warning!</strong> Some files don't match floor names.</div>").Append("<div style='height:200px;overflow-y:scroll'>");

                        foreach (var item in notTransfered)
                        {
                            builder.Append("<span style='font-size:0.9em;'>" + item + "</span><br/>");
                        }
                        builder.Append("</div>");
                        builder.Append("<br/><button class='btn btn-primary btn-sm goback'>GO BACK TO MAIN</button> <button class='btn btn-success btn-sm merge'>PROCEED TO MERGING</button><br/>");                       
                        return Content(builder.ToString());
                    }

                    if (files.Count == 0 && notTransfered.Count > 0)
                    {
                        builder.Append("<script>$('.panel-default').css('overflow-y','visible');$('.panel-body').css('height','400');</script>");

                        builder.Append("<div style='margin-top:10px;margin-bottom:10px' class='alert alert-danger'><strong>Warning!</strong> Some files don't match floor names.</div>").Append("<div style='height:200px;overflow-y:scroll'>");

                        foreach (var item in notTransfered)
                        {
                            builder.Append("<span style='font-size:0.9em;'>" + item + "</span><br/>");
                        }
                        builder.Append("</div>");
                        builder.Append("<br/><button class='btn btn-primary btn-sm goback'>GO BACK TO MAIN</button> <button class='btn btn-success btn-sm merge'>PROCEED TO MERGING</button><br/>");
                        return Content(builder.ToString());
                    }
                }
                else
                {
                    return Content("There are no files to transfer.");
                }
            }

            return Content("Directory doesn't exist.");

        }

        //get stores from file names of floor folder        
        public ActionResult StoresFromFloorFiles()
        {
            List<StoreFloor> storefloor = new List<StoreFloor>();
            List<string> matchedFilenames = new List<string>();
            List<string> unmatchedFilenames = new List<string>();
            List<string> DIVLOCS = new List<string>();
            List<string> storenames = new List<string>();            
            List<Store> stores = new List<Store>();
            List<string> storesWithoutCoverpages = new List<string>();           
            StringBuilder builder = new StringBuilder();
            StringBuilder builder2 = new StringBuilder();
            var path = HttpContext.Server.MapPath("~/DwfToPDF");
            var path2 = HttpContext.Server.MapPath("~/CoverPage");
            var path3 = HttpContext.Server.MapPath("~/Floors");
            var fnames = db.vw_DWFPDFs.Select(x => x.FNAME).Distinct().ToList(); //flornames from database

            //var path = @"\\SP000XSTLS01\SPACE_DFS$\SQFT Reports\_DWFS2PDFS ";
            //var path2 = @"\\MA000XSREA01\e$\SQFTPDFS\CoverPage";
            //var path3 = @"\\MA000XSREA01\e$\SQFTPDFS\Floors";


            var filesFromFloors = Directory.GetFiles(path3); //files from Floors foolder
            string[] fileEntries = Directory.GetFiles(path);
            if (fileEntries.Length > 0)
            {

                //crate a list of matched files (filename==floorname)
                foreach (var file in fileEntries)
                {
                    var fileToUpper = file.ToUpper();
                    var f = Path.GetFileName(fileToUpper).Replace(".PDF", "");
                    if (fnames.Exists(x => x == f))
                    {
                        matchedFilenames.Add(fileToUpper);
                        System.IO.File.Delete(file);
                    }
                    else
                    {
                        unmatchedFilenames.Add(Path.GetFileName(file));                         
                    }
                }

                //create a list of DIVLOCs related to matched files


                if (matchedFilenames.Count > 0) //if matched files >0
                {
                    foreach (var mFilename in matchedFilenames)
                    {
                        var fname = Path.GetFileName(mFilename).Replace(".PDF", ""); //striping out PDF part from filename
                        DIVLOCS.Add(db.vw_DWFPDFs.Where(x => x.FNAME == fname).Select(x => x.DIVLOC).FirstOrDefault()); //add divloc to a list of DIVLOCs
                        storefloor.Add(new StoreFloor() { DIVLOC = db.vw_DWFPDFs.Where(x => x.FNAME == fname).Select(x => x.DIVLOC).FirstOrDefault(), Store = db.vw_DWFPDFs.Where(x => x.FNAME == fname).Select(x => x.STORENAME).FirstOrDefault(), Floor = fname });
                    }

                    //create a list of divlocs without coverpages

                    foreach (var dloc in DIVLOCS.Distinct())
                    {
                        var fullFilePath = path2 + "/" + dloc + "INDEX.pdf";
                        var fullFilePath2 = path2 + "/" + dloc + "INDEX.PDF";
                        if (System.IO.File.Exists(fullFilePath) || System.IO.File.Exists(fullFilePath2))
                        {
                            //don't do anything  
                        }
                        else
                        {
                            storesWithoutCoverpages.Add(db.vw_DWFPDFs.Where(x=>x.DIVLOC==dloc).Select(x=>x.STORE).FirstOrDefault());
                            builder.Append(db.vw_DWFPDFs.Where(x => x.DIVLOC == dloc).Select(x => x.STORE).FirstOrDefault() + "<br/>");
                        }
                    }

                    // build a store object that will be passed to Merge function

                    foreach (var dloc in DIVLOCS.Distinct())
                    {
                        var strippedDIVLOC = dloc.Substring(2);
                        var filesContainsDIVLOC = filesFromFloors.Where(x => x.Contains(strippedDIVLOC)).ToList(); //get all files from Floors folder where filename contains DIVLOC minus 2 characters(ex:71003 becomes 003)
                        stores.Add(new Store() { DIVLOC = dloc, IndexFile = path2 + "\\" + dloc + "INDEX.pdf", FloorFiles = filesContainsDIVLOC });
                    }

                    //create a list of storenames

                    foreach (var dloc in DIVLOCS.Distinct())
                    {
                        storenames.Add(db.vw_DWFPDFs.Where(x=>x.DIVLOC==dloc).Select(x=>x.STORE).FirstOrDefault());
                    }

                } //end if matchedfiles

                // passing store object to MergePdfs

                if (stores.Count > 0 && storesWithoutCoverpages.Count < 1)
                {
                    foreach (var store in stores)
                    {
                        MergePdfs(store);
                    }

                    SendMail(storefloor, unmatchedFilenames, storesWithoutCoverpages);
                    return Content("<div class='alert alert-success'><strong>Success!</strong> All matched files have been merged and transfered.</div>");
                }

                else if (stores.Count > 0 && storesWithoutCoverpages.Count > 0)
                {
                    SendMail(storefloor, unmatchedFilenames, storesWithoutCoverpages);
                    return Content("<h4>Files have been merged and transfered.</h4><br/>Stores without coverpages:<br/> <span style='color:red'>" + builder + "</span>");
                }

                else
                {
                    return Content( "<div class='alert alert-warning'><strong>Warning!</strong> Can't find stores. Please check file names or floor names.</div>");
                }

            }//end if fileentries

            else
            {
                return Content( "<div class='alert alert-warning'><strong>Warning!</strong> There are no files to merge.</div>");
            }

        }

        // get list of all stores
        public ActionResult GetAllStores()
        {
            var allstores = db.vw_DWFPDFs.Select(x => new { divloc = x.DIVLOC, storename = x.STORE }).Distinct().ToList();

            StringBuilder builder = new StringBuilder();

            foreach (var item in allstores)
            {
                builder.Append("<input type='checkbox' class='divloc'  value=" + item.divloc + "> ");
                builder.Append(item.divloc + " - " + item.storename).Append("<br/>");

            }

            return Content(builder.ToString());
        }

        //generate cover pages
        public ActionResult CreateCoverPages(String divlocs)
        {

            if (divlocs != null)
            {
                //List<string> dlocs = db.vw_DWFPDFs.Select(x=>x.DIVLOC).Distinct().ToList();
                List<string> dlocs = divlocs.Split(',').ToList<string>();
                foreach (var item in dlocs)
                {
                    CreateCover(item);
                }

                if (dlocs.Count == 1)
                {
                    return Content("<div class='alert alert-success'><strong>Success!</strong> Cover page has been generated.</div>");
                }
                else
                {
                    return Content("<div class='alert alert-success'><strong>Success!</strong> Cover pages have been generated.</div>");
                }

            }
            else
            {
                return RedirectToAction("Index");
            }
        }      


        ///////////////////////////////////////////////////////////////functions

        //create cover page

        public void CreateCover(string DIVLOC = "")
        {
            if (DIVLOC != "")
            {
                int i = 86; //to write text on new line after each iteration
                var stores = db.vw_DWFPDFs.Where(x => x.DIVLOC == DIVLOC).ToList();
                var STORENAME = stores.Select(x => x.STORE).FirstOrDefault();

                
                //create pdf document
                PdfDocument document = new PdfDocument();

                // Create an empty page      
                PdfPage page = document.AddPage();
                page.Orientation = PageOrientation.Landscape;

                // Get an XGraphics object for drawing     
                XGraphics gfx = XGraphics.FromPdfPage(page);

                // Create a font   
                XFont font = new XFont("Verdana", 10, XFontStyle.Regular);
                XFont font2 = new XFont("Verdana", 9, XFontStyle.Regular);
                XFont font3 = new XFont("Verdana", 8, XFontStyle.Bold);

                //blue rectangle
                XPen pen = new XPen(XColors.Blue, 15);

                gfx.DrawRectangle(pen, 200, 52, 400, 10);


                // store name
                gfx.DrawString(STORENAME, font, XBrushes.White,

                new XRect(0, 50, page.Width, page.Height),

                XStringFormats.TopCenter);

                //spacekey rectangle
                XPen pen2 = new XPen(XColors.Beige, 15);

                gfx.DrawRectangle(pen2, 200, 77, 150, 10);

                // floor rectangle
                XPen pen3 = new XPen(XColors.BlanchedAlmond, 15);

                gfx.DrawRectangle(pen3, 350, 77, 250, 10);


                //spacekey text
                gfx.DrawString("SPACEKEY", font2, XBrushes.Black,

               new XRect(245, 76, page.Width, page.Height),

               XStringFormats.TopLeft);

                //floor text
                gfx.DrawString("FLOOR", font2, XBrushes.Black,

               new XRect(460, 76, page.Width, page.Height),

               XStringFormats.TopLeft);

                //loops


                foreach (var item in stores)
                {
                    i = i + 15;
                    //drawing spacekeys
                    gfx.DrawString(item.SPACEKEY, font2, XBrushes.Black,

                    new XRect(255, i, page.Width, page.Height),

                    XStringFormats.TopLeft);

                    //drawing floors

                    gfx.DrawString(item.FNAME, font2, XBrushes.Black,

                    new XRect(420, i, page.Width, page.Height),

                    XStringFormats.TopLeft);

                    //drawing FLOOR_ID

                    gfx.DrawString(item.FLOOR_ID, font2, XBrushes.Black,

                    new XRect(510, i, page.Width, page.Height),

                    XStringFormats.TopLeft);

                }// end loop


                //drawing buttom text

                gfx.DrawString("The listed plans represent the latest available drawings by floor but may or ", font3, XBrushes.Black,

               new XRect(0, i + 30, page.Width, page.Height),

               XStringFormats.TopCenter);

                gfx.DrawString("may not reflect the data featured on the latest year-end SAPA vintage.", font3, XBrushes.Black,

               new XRect(0, i + 40, page.Width, page.Height),

              XStringFormats.TopCenter);


                //saving document

                var path = HttpContext.Server.MapPath("~/CoverPage");
                //var path = @"\\MA000XSREA01\e$\SQFTPDFS\CoverPage";

                document.Save(path + "/" + DIVLOC + "INDEX.pdf");


            }


        }

        //merge floor and index pdf files
        public void MergePdfs(Store store)
        {
            var path = HttpContext.Server.MapPath("~/Stores");
            var path2 = HttpContext.Server.MapPath("~/Portal");

            //var path = @"\\ma000xsrea01\e$\SQFTPDFS\Stores";
            //var path2 = @"\\mymacys.net\DavWWWRoot\sites\propertydevelopment\Recent_Floor_Plans";



            // Get some file names 
            List<string> files = store.FloorFiles;
            if (System.IO.File.Exists(store.IndexFile))
            {
                  files.Insert(0, store.IndexFile);
            }          

            // Open the output document 
            PdfDocument outputDocument = new PdfDocument();

            // Iterate files 
            foreach (string file in files)
            {

                // Open the document to import pages from it. 
                PdfDocument inputDocument = PdfReader.Open(file, PdfDocumentOpenMode.Import);
                // Iterate pages 
                int count = inputDocument.PageCount;
                for (int idx = 0; idx < count; idx++)
                {
                    // Get the page from the external document... 

                    PdfPage page = inputDocument.Pages[idx];

                    // ...and add it to the output document. 

                    outputDocument.AddPage(page);
                }

            }

            // Save the document...          

            outputDocument.Save(path + "/" + store.DIVLOC + ".pdf"); //save to Stores folder
            outputDocument.Save(path2 + "/" + store.DIVLOC + ".pdf");//save to Portal folder

        }

        //rename floors
        public void RenameFloors()
        {
            List<string> floors11x17 = new List<string>();

            var floors = db.vw_DWFPDFs.Select(x => x.FNAME).ToList();
            var DWFtoPDFpath = HttpContext.Server.MapPath("~/DwfToPDF");

            //var DWFtoPDFpath = @"\\SP000XSTLS01\SPACE_DFS$\SQFT Reports\_DWFS2PDFS";

            if (Directory.Exists(DWFtoPDFpath))
            {
                string[] fileEntries = Directory.GetFiles(DWFtoPDFpath);
                if (fileEntries.Length > 0)
                {
                    foreach (var file in fileEntries)
                    {
                        if (Path.GetFileName(file.ToUpper()).Contains("11X17"))
                        {
                            floors11x17.Add(file.ToUpper());
                        }
                    }
                    foreach (string floor11x17 in floors11x17)
                    {
                        var f = Path.GetFileName(floor11x17).Replace("-11X17.PDF", "");
                        if (floors.Exists(x => x == f))
                        {
                            var x = floor11x17.Replace(Path.GetFileName(floor11x17), f + ".pdf");
                            System.IO.File.Copy(floor11x17, x, true);
                            System.IO.File.Delete(floor11x17);
                        }
                    }
                }
            }

        }

        //send notification
        public void SendMail(List<StoreFloor>storefloors, List<string>unmatchedfiles, List<string>withoutcoverpages)
        {
            StringBuilder sStores = new StringBuilder();
            StringBuilder sUnmatched = new StringBuilder();
            StringBuilder sWithoutCover = new StringBuilder();
           

                string body = "";

                string body1 = "";

                if (unmatchedfiles.Count==0 && withoutcoverpages.Count==0)
                {
                    sStores.Append("<h4>The following floors have been successfully updated:</h4>");
                    foreach (var item in storefloors)
                    {
                        sStores.Append("["+item.DIVLOC+"] - "+item.Store +" - "+item.Floor+ "<br/>");
                       
                    }
                    body = sStores.ToString();
                    body1 = sStores.ToString();
                }

                else if (unmatchedfiles.Count != 0 && withoutcoverpages.Count == 0)
                {
                 
                    sStores.Append("<h4>The following floors have been successfully updated:</h4>");
                    foreach (var item in storefloors)
                    {
                        sStores.Append("[" + item.DIVLOC + "] - " + item.Store + " - " + item.Floor + "<br/>");
                       
                    }

                    sUnmatched.Append("<h4>The following floors cannot be found on the database:</h4>");
                    foreach (var item in unmatchedfiles)
                    {
                        sUnmatched.Append(item + "<br/>");
                    }

                    body = sStores.ToString()+"<br/>";
                    body1 = sStores.ToString() + "<br/>" + sUnmatched.ToString();
                }

                else if (unmatchedfiles.Count != 0 && withoutcoverpages.Count != 0)
                {
                  
                    sStores.Append("<h4>The following floors have been successfully updated:</h4>");
                    foreach (var item in storefloors)
                    {
                        sStores.Append("[" + item.DIVLOC + "] - " + item.Store + " - " + item.Floor + "<br/>");
                    }

                    sUnmatched.Append("<h4>The following floors cannot be found on the database:</h4>");
                    foreach (var item in unmatchedfiles)
                    {
                        sUnmatched.Append(item + "<br/>");
                    }

                    sWithoutCover.Append("<h4>Stores without coverpage:</h4>");
                    foreach (var item in withoutcoverpages)
                    {
                        sWithoutCover.Append(item + "<br/>");
                    }

                    body = sStores.ToString() + "<br/>";
                    body1 = sStores.ToString() + "<br/>" + sUnmatched.ToString() + "<br/>" + sWithoutCover.ToString();
                    
                }
                else
                {
                    body = "no content";
                    body1 = "no content";
                }
            
                var message = new MailMessage();
                message.To.Add(new MailAddress("tim.ahtirski@macys.com"));  // replace with valid value 
               // message.To.Add(new MailAddress("maureen.pinyard@macys.com"));  // replace with valid value 
               // message.To.Add(new MailAddress("davin.monk@macys.com"));  // replace with valid value 
                message.From = new MailAddress("FloorPlanPDFs@macys.com");  // replace with valid value
                message.Subject = "Floor Plan Tool Notification";
                message.Body = body;
                message.IsBodyHtml = true;

                using (var smtp = new SmtpClient())
                {
                    var credential = new NetworkCredential
                    {
                        UserName = "FloorPlanPDFs@macys.com" 
                       
                    };
                    smtp.Credentials = credential;
                    smtp.Host = "appmail.federated.fds";
                    smtp.Port = 25;
                    smtp.EnableSsl = false;
                    smtp.Send(message);
                   
                }//   

                var message1 = new MailMessage();
               // message1.To.Add(new MailAddress("peri.georgiades@macys.com"));  // replace with valid value 
                message1.To.Add(new MailAddress("tim.ahtirski@macys.com"));  // replace with valid value 
                message1.From = new MailAddress("FloorPlanPDFs@macys.com");  // replace with valid value
                message1.Subject = "Floor Plan Tool Notification";
                message1.Body = body1;
                message1.IsBodyHtml = true;

                using (var smtp = new SmtpClient())
                {
                    var credential = new NetworkCredential
                    {
                        UserName = "FloorPlanPDFs@macys.com" 
                       
                    };
                    smtp.Credentials = credential;
                    smtp.Host = "appmail.federated.fds";
                    smtp.Port = 25;
                    smtp.EnableSsl = false;
                    smtp.Send(message1);

                }//  
        } 
    }
}