﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PeriSQFT.Models
{
    public class StoreFloor
    {
        public string DIVLOC { get; set; }
        public string Store { get; set; }
        public string Floor { get; set; }
    }
}