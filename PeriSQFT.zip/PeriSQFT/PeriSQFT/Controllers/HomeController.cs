﻿using PeriSQFT.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace PeriSQFT.Controllers
{
    public class HomeController : Controller
    {
        private SPACE11Entities db = new SPACE11Entities();
        public ActionResult Index()
        {
            return View();
        }





        public ActionResult GetStores()
        {

            var list = db.vw_DWFPDFs.Select(x => x.STORE).Distinct().Take(5).ToList();

            return Json(list,JsonRequestBehavior.AllowGet);
        
        }


       
    }
}